#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <pwd.h>
#include <errno.h>

#define MAX_LEN_ALLOWED 10000

void **parse(char **argv, char **command_argv)
{
    int x = 1, y = 0;
    
    while(argv[x] != NULL)
    {
        command_argv[y] = argv[x];
        x++;
        y++;
    }
    command_argv[y] = NULL;
}

void execute(uid_t target_eff_uid, char **command)
{
    pid_t pid = vfork();

    if(pid < 0)
    {
        perror("vfork");
        exit(EXIT_FAILURE);
    }

    if(pid == 0)
    {
        if((setuid(target_eff_uid) == -1))
        {
            perror("seteuid");
            exit(EXIT_FAILURE);
        }

        execvp(command[0], command);
        perror("execvp");
        exit(EXIT_FAILURE);
    }
    else
    {
        int status;
        waitpid(pid, &status, 0);

        seteuid(getuid());
    }
}

int main(int argc, char **argv)
{
    if(argc < 2)
    {
        printf("Use: %s <bin> [args]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    uid_t real_uid = getuid();
    uid_t eff_uid = geteuid();

    uid_t target_eff_uid = 0;
    char **command_args = (char **)malloc(sizeof(char*) *MAX_LEN_ALLOWED);

    parse(argv, command_args);

    struct stat file_data;
    char *File = argv[1];

    if(stat(File, &file_data) < 0)
    {
        perror("stat");
        exit(EXIT_FAILURE);
        return 0;
    }

    if(!(file_data.st_mode & S_IXUSR))
    {
        fprintf(stderr, "Error: Insufficient permission to execute the file %s \n", File);
        exit(EXIT_FAILURE);
        return 0;
    }

    if(file_data.st_uid != 0){
        target_eff_uid = file_data.st_uid;
    }

    execute(target_eff_uid, command_args);
    
    return 0;
}
