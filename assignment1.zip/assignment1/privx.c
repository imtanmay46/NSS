#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <pwd.h>
#include <sys/stat.h>
#include <sys/wait.h>

#define MAX_COMMAND_SIZE 10000

bool is_uid(char *str) {
    int i = strlen(str);
    while (i--) if (str[i] > 57 || str[i] < 48) return false;
    return true;
}

void **parse_command(char **argv, char **command_argv) {
    int i = 1;
    int j = 0;
    while (argv[i] != NULL) {
        command_argv[j] = argv[i];
        i++;
        j++;
    }

    command_argv[j] = NULL;
}

void execute(uid_t target_euid, char **command) {
    pid_t pid = vfork();
    if (pid < 0) exit(1);
    if (pid == 0) {
        if (setuid(target_euid) == -1) {
            perror("seteuid");
            exit(1);
        }

        execvp(command[0], command);
        perror("exec");
        exit(1);
    }
    else {
        int status;
        waitpid(pid, &status, 0);
    }
}

int main(int argc, char **argv) {
    uid_t ruid = getuid();
    uid_t euid = geteuid();
    uid_t target_euid = 0;

    char **command_args = (char **)malloc(sizeof(char) * MAX_COMMAND_SIZE);

    if (argc < 2) {
        printf("Usage: %s <binary> [arguments]\n", argv[0]);
        exit(0);
    }

    parse_command(argv, command_args);

    char *filename = argv[argc-1];
    struct stat file_info;

    if (stat(filename, &file_info) == -1) {
        perror("stat");
        return false;
    }
    
    target_euid = file_info.st_uid;
    
    execute(target_euid, command_args);

    return 0;
}











// #include <stdio.h>
// #include <stdlib.h>
// #include <string.h>
// #include <stdbool.h>
// #include <unistd.h>
// #include <sys/stat.h>
// #include <sys/wait.h>
// #include <sys/types.h>
// #include <pwd.h>

// int main(int argc, char **argv)
// {
//         uid_t real_uid = getuid();
//         uid_t eff_uid = geteuid();

//         uid_t target_eff_uid = 0;
//         char **command_args = (char **)malloc(sizeof(char) *MAX_LEN_ALLOWED);

//         if(argc <=1)
//         {
//                 printf("Use: %s <bin> [args]\n", argv[0]);
//                 exit(0);
//         }

//         parse(argv, command_args);

//         struct stat file_data;    
//         char *File = argv[argc - 1];

//         if(stat(File, &file_data) == -1)
//         {
//                 perror("stat");
//                 return false;
//         }

//         target_eff_uid = file_data.st_uid;

//         execute(target_eff_uid, command_args);
//         return 0;
// }






// #include <stdio.h>
// #include <stdlib.h>
// #include <string.h>
// #include <stdbool.h>
// #include <unistd.h>
// #include <sys/stat.h>
// #include <sys/wait.h>
// #include <sys/types.h>
// #include <pwd.h>

// #define MAX_LEN_ALLOWED 10000

// void **parse(char **argv, char **command_argv)
// {
//         int x = 1, y = 0;
//         while(argv[x] != NULL)
//         {
//                 command_argv[y] = argv[x];
//                 x++; y++;
//         }
//         command_argv[y] = NULL;
// }

// void execute(uid_t target_eff_uid, char **command)
// {
//         pid_t pid = vfork();

//         if(pid < 0)
//                 exit(1);

//         if(pid == 0)
//         {
//                 if(setuid(target_eff_uid) == -1)
//                 {
//                         perror("seteuid");
//                         exit(1);
//                 }

//                 execvp(command[0], command);
//                 perror("exec");
//                 exit(1);
//         }
//         else
//         {
//                 int status;
//                 waitpid(pid, &status, 0);
//         }
// }

// int main(int argc, char **argv)
// {
//         uid_t real_uid = getuid();
//         uid_t eff_uid = geteuid();

//         uid_t target_eff_uid = 0;
//         char **command_args = (char **)malloc(sizeof(char) *MAX_LEN_ALLOWED);

//         if(argc <=1)
//         {
//                 printf("Use: %s <bin> [args]\n", argv[0]);
//                 exit(0);
//         }

//         parse(argv, command_args);

//         struct stat file_data;
//         char *File = argv[argc - 1];

//         if(stat(File, &file_data) == -1)
//         {
//                 perror("stat");
//                 return false;
//         }

//         target_eff_uid = file_data.st_uid;

//         execute(target_eff_uid, command_args);
//         return 0;
// }
