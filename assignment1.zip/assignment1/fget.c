#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/xattr.h>
#include <string.h>
#include <stdbool.h>
#include <sys/types.h>
#include <pwd.h>
#include <errno.h>
#include <grp.h>
#include <sys/stat.h>

#define ACL_ATTR "user.acl"

bool has_dac_read_permission(const char *filename, uid_t uid) {
    struct stat file_stat;

    if (stat(filename, &file_stat) == -1) {
        perror("stat");
        return false;
    }

    if (uid == file_stat.st_uid) {
        if (file_stat.st_mode & S_IRUSR) {
            return true;
        }
    }

    if (file_stat.st_mode & S_IROTH) {
        return true;
    }

    return false;
}

bool has_acl_read_permission(const char *filename, uid_t user_uid) {
    char acl_string[1024];
    ssize_t size = getxattr(filename, ACL_ATTR, acl_string, sizeof(acl_string));

    if (size == -1) {
        return has_dac_read_permission(filename, user_uid);
    }

    char target_str[512];

    struct passwd *pw = getpwuid(user_uid);

    if (strstr(acl_string, pw->pw_name) == NULL) {
        return has_dac_read_permission(filename, user_uid);
    }

    snprintf(target_str, sizeof(target_str), "user:%s:r", pw->pw_name);

    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    struct group *gr = getgrgid(pw->pw_gid);
    snprintf(target_str, sizeof(target_str), "group:%s:r", gr->gr_name);
    
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    return false;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    char *filename = argv[1];
    uid_t user_uid = getuid();

    if (!has_acl_read_permission(filename, user_uid)) {
        fprintf(stderr, "You do not have read permission for %s.\n", filename);
        return 1;
    }

    FILE *file;
    file = fopen(filename, "r");

    if (file == NULL) {
        perror("fopen");
        return 1;
    }

    char *line = NULL;
    size_t line_size = 0;
    ssize_t read;

    while ((read = getline(&line, &line_size, file)) != -1) {
        printf("%s", line);
    }
    printf("\n");

    free(line);
    fclose(file);

    return 0;
}