#include <stdio.h>
#include <stdbool.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pwd.h>
#include <grp.h>
#include <sys/xattr.h>
#include <sys/stat.h>

#define ACL_ATTR "user.acl"
#define MAX_ATTR_SIZE 10000

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    char *filename = argv[1];
    char *acl_string = (char *)malloc(MAX_ATTR_SIZE * sizeof(char));
    acl_string[0] = '\0';

    ssize_t size = getxattr(filename, ACL_ATTR, acl_string, MAX_ATTR_SIZE);

    struct stat info;
    if (stat(filename, &info) == -1) {
        perror("stat");
    }

    struct passwd *pw = getpwuid(info.st_uid);
    struct group  *gr = getgrgid(info.st_gid);

    printf("# Filename: %s\n", filename);
    printf("# Owner: %s\n", pw->pw_name);
    printf("# Group: %s\n", gr->gr_name);

    printf("%s\n", acl_string);

    return 0;
}