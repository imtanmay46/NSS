#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/xattr.h>
#include <string.h>
#include <stdbool.h>
#include <sys/types.h>
#include <pwd.h>
#include <errno.h>
#include <grp.h>
#include <sys/stat.h>

#define ACL_ATTR "user.acl"

bool has_dac_write_permission(const char *filename, uid_t uid) {
    struct stat file_stat;

    if (stat(filename, &file_stat) == -1) {
        perror("stat");
        return false;
    }

    if (uid == file_stat.st_uid) {
        if (file_stat.st_mode & S_IWUSR) {
            return true;
        }
    }

    if (file_stat.st_mode & S_IWOTH) {
        return true;
    }

    return false;
}

bool has_acl_write_permission(const char *filename, uid_t user_uid) {
    char acl_string[1024];
    ssize_t size = getxattr(filename, ACL_ATTR, acl_string, sizeof(acl_string));

    if (size == -1) {
        return has_dac_write_permission(filename, user_uid);
    }


    char target_str[512];
    char target_str_[512];

    struct passwd *pw = getpwuid(user_uid);

    if (strstr(acl_string, pw->pw_name) == NULL) {
        return has_dac_write_permission(filename, user_uid);
    }

    snprintf(target_str, sizeof(target_str), "user:%s:rw", pw->pw_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    snprintf(target_str, sizeof(target_str), "user:%s:-w", pw->pw_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    struct group *gr = getgrgid(pw->pw_gid);

    snprintf(target_str, sizeof(target_str), "group:%s:rw", gr->gr_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    snprintf(target_str, sizeof(target_str), "group:%s:-w", gr->gr_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    return false;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <string> <filename>\n", argv[0]);
        return 1;
    }

    char *content = argv[1];
    char *filename = argv[2];
    FILE *file;
    uid_t user_uid = getuid();
    
    if (!has_acl_write_permission(filename, user_uid)) {
        fprintf(stderr, "You do not have write permission for %s.\n", filename);
        return 1;
    }

    file = fopen(filename, "w");

    if (file == NULL) {
        printf("Unable to create or open file '%s'.\n", filename);
        return 1;
    }

    if (fprintf(file, "%s", content) < 0) {
        printf("Error writing content to file '%s'.\n", filename);
        fclose(file);
        return 1;
    }

    fclose(file);

    printf("Content successfully written to file '%s'.\n", filename);

    return 0;
}