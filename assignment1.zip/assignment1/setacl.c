#include <stdio.h>
#include <stdbool.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/xattr.h>

#define ACL_ATTR "user.acl"
#define MAX_ATTR_SIZE 10000

bool is_valid_permission(const char *permission) {
    if (strlen(permission) != 3 ||
        (permission[0] != 'r' && permission[0] != '-') ||
        (permission[1] != 'w' && permission[1] != '-') ||
        (permission[2] != 'x' && permission[2] != 's' && permission[2] != '-') ||
        (permission[2] == 's' && permission[0] == '-' && permission[1] == '-')) return false;
    return true;
}

void search_string(char *string, char *pattern, int *start, int *end) {
    char *found = strstr(string, pattern);

    if (found != NULL) {
        *start = found - string;
        *end = *start + strlen(pattern) - 1;
    } else {
        *start = -1;
        *end = -1;
    }
}

int main(int argc, char **argv) {
    int opt;
    char *username = NULL;
    char *groupname = NULL;
    char *permission = NULL;
    char *filename = NULL;
    bool remove_acl = false;

    while ((opt = getopt(argc, argv, "u:g:p:d")) != -1) {
        switch (opt) {
            case 'u':
                username = optarg;
                break;
            case 'g':
                groupname = optarg;
                break;
            case 'p':
                permission = optarg;
                if (!is_valid_permission(permission)) {
                    fprintf(stderr, "Invalid permission: %s\n", permission);
                    return EXIT_FAILURE;
                }
                break;
            case 'd':
                remove_acl = true;
                break;
            default:
                fprintf(stderr, "Usage: %s [-d] [-u username] [-g groupname] [-p permission] filename\n", argv[0]);
                return EXIT_FAILURE;
        }
    }

    filename = argv[optind];
    
    if (remove_acl) {
        if (argc != 3) {
            fprintf(stderr, "Only a filename can be provided with -d flag.\n");
            return EXIT_FAILURE;
        }

        if (removexattr(filename, ACL_ATTR) == -1) {
            perror("removexattr");
            return EXIT_FAILURE;
        }

        printf("Permissions removed successfully.\n");
        return 0;
    }

    if (username == NULL && groupname == NULL) {
        fprintf(stderr, "Either -u or -g must be provided.\n");
        return EXIT_FAILURE;
    }

    if (permission == NULL) {
        fprintf(stderr, "A permission must be provided.\n");
        return EXIT_FAILURE;
    }

    if (optind >= argc) {
        fprintf(stderr, "A filename must be provided.\n");
        return EXIT_FAILURE;
    }

    struct stat file_stat;
    if (stat(filename, &file_stat) == -1) {
        perror("stat");
        return 1;
    }

    if (getuid() != 0) {
        if (getuid() != file_stat.st_uid) {
            fprintf(stderr, "You do not have the permission to modify ACL of %s\n", filename);
            return EXIT_FAILURE;
        }
    }

    char *acl_string = (char *)malloc(MAX_ATTR_SIZE * sizeof(char));
    acl_string[0] = '\0';

    ssize_t size = getxattr(filename, ACL_ATTR, acl_string, MAX_ATTR_SIZE);

    if (username != NULL) {
        int start, end;
        search_string(acl_string, username, &start, &end);
        end++;
        if (end > 0) {
            for (int i=0; i<3; i++) {
                acl_string[++end] = permission[i];
            }
        } else {
            strcat(acl_string, "user:");
            strcat(acl_string, username);
            strcat(acl_string, ":");
            strcat(acl_string, permission);
            strcat(acl_string, "\n");
        }
    }

    if (groupname != NULL) {
        int start, end;
        search_string(acl_string, groupname, &start, &end);
        end++;
        if (end > 0) {
            for (int i=0; i<3; i++) {
                acl_string[++end] = permission[i];
            }
        } else {
            strcat(acl_string, "group:");
            strcat(acl_string, groupname);
            strcat(acl_string, ":");
            strcat(acl_string, permission);
            strcat(acl_string, "\n");
        }
    }

    if (setxattr(filename, ACL_ATTR, acl_string, strlen(acl_string), 0) == -1) {
        perror("setxattr");
        return 1;
    }

    printf("Permissions set successfully.\n");

    return 0;
}