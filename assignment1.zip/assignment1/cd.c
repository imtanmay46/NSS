#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/xattr.h>
#include <string.h>
#include <stdbool.h>
#include <sys/types.h>
#include <pwd.h>
#include <errno.h>
#include <grp.h>
#include <sys/stat.h>

#define ACL_ATTR "user.acl"

bool has_dac_exec_permission(const char *filename, uid_t uid) {
    struct stat file_stat;

    if (stat(filename, &file_stat) == -1) {
        perror("stat");
        return false;
    }

    if (uid == file_stat.st_uid) {
        if (file_stat.st_mode & S_IWUSR) {
            return true;
        }
    }

    if (file_stat.st_mode & S_IWOTH) {
        return true;
    }

    return false;
}

bool has_acl_exec_permission(const char *filename, uid_t user_uid) {
    char acl_string[1024];
    ssize_t size = getxattr(filename, ACL_ATTR, acl_string, sizeof(acl_string));

    if (size == -1) {
        return has_dac_exec_permission(filename, user_uid);
    }

    char target_str[512];

    struct passwd *pw = getpwuid(user_uid);

    if (strstr(acl_string, pw->pw_name) == NULL) {
        return has_dac_exec_permission(filename, user_uid);
    }

    snprintf(target_str, sizeof(target_str), "user:%s:rwx", pw->pw_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    snprintf(target_str, sizeof(target_str), "user:%s:r-x", pw->pw_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    snprintf(target_str, sizeof(target_str), "user:%s:-wx", pw->pw_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    snprintf(target_str, sizeof(target_str), "user:%s:--x", pw->pw_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    struct group *gr = getgrgid(pw->pw_gid);

    snprintf(target_str, sizeof(target_str), "group:%s:rwx", gr->gr_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    snprintf(target_str, sizeof(target_str), "group:%s:r-x", gr->gr_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    snprintf(target_str, sizeof(target_str), "group:%s:-wx", gr->gr_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

        snprintf(target_str, sizeof(target_str), "group:%s:--x", gr->gr_name);
    if (strstr(acl_string, target_str) != NULL) {
        return true;
    }

    return false;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <directory>\n", argv[0]);
        return EXIT_FAILURE;
    }

    const char *dirname = argv[1];
    uid_t user_uid = getuid();

    if (has_acl_exec_permission(dirname, user_uid)) {
        if (chdir(dirname) == 0) {
            printf("Changed directory to: %s\n", dirname);
            return EXIT_SUCCESS;
        } else {
            perror("chdir");
            return EXIT_FAILURE;
        }
    } else {
        fprintf(stderr, "You do not have permission to change to this directory.\n");
        return EXIT_FAILURE;
    }
}
