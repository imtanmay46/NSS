#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <sys/types.h>
#include <sys/access.h>
#include <pwd.h>
#include <grp.h>
#include <errno.h>

#define ACL_ATTRIBUTE "user.acl"

bool is_dac_read_permitted(const char *File, uid_t uid)
{
    struct stat file_info;
    bool condition;

    condition = (stat(File, &file_info) < 0);
    if(condition)
    {
        perror("stat");
        return 0;
    }

    condition = (uid == file_info.st_uid);
    if(condition)
    {
        if(file_info.st_mode & S_IRUSR){
            return 1;
        }
    }

    if(file_info.st_mode & S_IROTH){
        return 1;
    }

    condition = (access(File, R_OK) == 0);
    if(condition){
        return 1;
    }

    return 0;
}

bool is_acl_read_permitted(const char *File, uid_t u_uid)
{
    char acl_str[1024];
    ssize_t size = getxattr(File, ACL_ATTRIBUTE, acl_str, sizeof(acl_str));
    bool  condition = ((size < 0) && (errno == ENODATA));

    if(condition){
        fprintf(stderr, "Falling back to DAC, no ACL found...\n");
        return is_dac_read_permitted(File, u_uid);
    }

    char target_str[512];
    struct passwd *pw = getpwuid(u_uid);

    if(strstr(acl_str, pw->pw_name) == NULL){
        return is_dac_read_permitted(File, u_uid);
    }

    snprintf(target_str, sizeof(target_str), "user:%s:r", pw->pw_name);
    condition = (strstr(acl_str, target_str) != NULL);

    if(condition){
        return 1;
    }

    struct group *gr = getgrgid(pw->pw_gid);
    snprintf(target_str, sizeof(target_str), "group:%s:r", gr->gr_name);
    
    if(condition){
        return 1;
    }

    return is_dac_read_permitted(File, u_uid);
}

int main(int argc, char *argv[])
{
    if(argc != 2)
    {
        fprintf(stderr, "Usage: %s <File>\n", argv[0]);
        return EXIT_FAILURE;
    }

    char *File = argv[1];
    uid_t u_uid = getuid();
    bool condition;

    condition = (is_acl_read_permitted(File, u_uid) == 0);
    if(condition)
    {
        fprintf(stderr, "Insufficient Permission to read the file: %s.\n", File);
        return EXIT_FAILURE;
    }

    FILE *file;
    file = fopen(File, "r");

    if(file == NULL)
    {
        perror("fopen");
        return EXIT_FAILURE;
    }

    ssize_t read;
    char *line = NULL;
    size_t line_len = 0;

    condition = ((read = getline(&line, &line_len, file)) != -1);

    while(condition){
        printf("%s", line);
    }
    printf("\n");

    free(line);
    fclose(file);

    return 0;
}