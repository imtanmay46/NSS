#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <errno.h>

#define ACL_ATTRIBUTE "user.acl"

bool is_dac_exec_permitted(const char *File, uid_t uid)
{
    struct stat file_info;

    if(stat(File, &file_info) < 0)
    {
        perror("stat");
        return 0;
    }

    if(uid == file_info.st_uid)
    {
        if(file_info.st_mode & S_IWUSR){
            return 1;
        }
    }

    if(file_info.st_mode & S_IWOTH){
        return 1;
    }

    if(access(File, X_OK) == 0){
        return 1;
    }

    return 0;
}

void helper_func_pwd(char *target, struct passwd *pw, int permission_code)
{
    if(permission_code == 7)
        snprintf(target, sizeof(target), "user:%s:rwx", pw->pw_name);
    
    else if(permission_code == 5)
        snprintf(target, sizeof(target), "user:%s:r-x", pw->pw_name);
    
    else if(permission_code == 3)
        snprintf(target, sizeof(target), "user:%s:-wx", pw->pw_name);
    
    else
        snprintf(target, sizeof(target), "user:%s:--x", pw->pw_name);
}

void helper_func_gr(char *target, struct group *gr, int permission_code)
{
    if(permission_code == 7)
        snprintf(target, sizeof(target), "group:%s:rwx", gr->gr_name);
    
    else if(permission_code == 5)
        snprintf(target, sizeof(target), "group:%s:r-x", gr->gr_name);
    
    else if(permission_code == 3)
        snprintf(target, sizeof(target), "group:%s:-wx", gr->gr_name);
    
    else
        snprintf(target, sizeof(target), "group:%s:--x", gr->gr_name);
}

bool is_acl_exec_permitted(const char *File, uid_t u_uid)
{
    char acl_str[1024];
    ssize_t size = getxattr(File, ACL_ATTRIBUTE, acl_str, sizeof(acl_str));

    if((size < 0) && (errno == ENODATA)){
        fprintf(stderr, "Falling back to DAC, no ACL found...\n");
        return is_dac_exec_permitted(File, u_uid);
    }

    char target_str[512];
    struct passwd *pw = getpwuid(u_uid);

    if(strstr(acl_str, pw->pw_name) == NULL){
        return is_dac_exec_permitted(File, u_uid);
    }

    helper_func_pwd(target_str, pw, 7);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    helper_func_pwd(target_str, pw, 5);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    helper_func_pwd(target_str, pw, 3);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    helper_func_pwd(target_str, pw, 1);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    struct group *gr = getgrgid(pw->pw_gid);

    helper_func_gr(target_str, gr, 7);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    helper_func_gr(target_str, gr, 5);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    helper_func_gr(target_str, gr, 3);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    helper_func_gr(target_str, gr, 1);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    return is_dac_exec_permitted(File, u_uid);
}

int main(int argc, char **argv)
{
    if(argc != 2)
    {
        fprintf(stderr, "Usage: %s <directory>\n", argv[0]);
        return EXIT_FAILURE;
    }

    uid_t u_uid = getuid();
    const char *directory_name = argv[1];

    if(is_acl_exec_permitted(directory_name, u_uid))
    {
        if(chdir(directory_name) != 0)
        {
            perror("chdir");
            return EXIT_FAILURE;
        }
        else
        {
            printf("Switched directory to: %s\n", directory_name);
            return EXIT_SUCCESS;
        }
    }
    else
    {
        fprintf(stderr, "Insufficient Permission to change to this directory.\n");
        return EXIT_FAILURE;
    }
}