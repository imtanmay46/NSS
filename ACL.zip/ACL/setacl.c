#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <errno.h>

#define ACL_ATTRIBUTE "user.acl"
#define MAX_ATTRIBUTE_LEN 10000

bool is_permitted(const char *permission)
{
    if(((strlen(permission) != 3)|| 
        ((permission[0] != 'r') && (permission[0] != '-')) || 
        ((permission[1] != 'w') && (permission[1] != '-')) || 
        ((permission[2] != 'x') && (permission[2] != 's') && (permission[2] != '-')) || 
        ((permission[2] == 's') && (permission[0] == '-') && (permission[1] == '-'))))
        return 0;

    return 1;
}

void string_search(char *str, char *pattern, int *i, int *j) {
    char *match = strstr(str, pattern);

    if(match == NULL)
    {
        *i = -1;
        *j = -1;
    } 
    else
    {
        *i = match - str;
        *j = *i + strlen(pattern) - 1;
    }
}

int main(int argc, char **argv)
{
    int opt;
    char *u_name = NULL;
    char *gr_name = NULL;
    char *permission = NULL;
    char *File = NULL;
    bool rm_acl = false;

    while(((opt = getopt(argc, argv, "u:g:p:d")) != -1))
    {
        switch(opt)
        {
            case 'g':
                gr_name = optarg;
                break;
            case 'u':
                u_name = optarg;
                break;
            case 'd':
                rm_acl = true;
                break;
            case 'p':
                permission = optarg;
                if(is_permitted(permission) == 0)
                {
                    fprintf(stderr, "Action Not Permitted: %s\n", permission);
                    return EXIT_FAILURE;
                }
                break;
            default:
                fprintf(stderr, "Usage: %s [-d] [-u u_name] [-g gr_name] [-p permission] File\n", argv[0]);
                return EXIT_FAILURE;
        }
    }

    struct stat file_stat;
    File = argv[optind];

    if((stat(File, &file_stat) < 0))
    {
        perror("stat");
        return EXIT_FAILURE;
    }

    if(rm_acl == 1)
    {
        if(argc != 3)
        {
            fprintf(stderr, "File can be provided with -d flag only.\n");
            return EXIT_FAILURE;
        }

        if(removexattr(File, ACL_ATTRIBUTE) < 0)
        {
            perror("removexattr");
            return EXIT_FAILURE;
        }

        printf("Permissions successfully removed.\n");
        return 0;
    }

    if(permission == NULL)
    {
        fprintf(stderr, "Permission is required for this action.\n");
        return EXIT_FAILURE;
    }

    if(u_name == NULL && gr_name == NULL)
    {
        fprintf(stderr, "One of -u or -g must be provided for this action.\n");
        return EXIT_FAILURE;
    }

    if(optind >= argc)
    {
        fprintf(stderr, "File must be provided for this action.\n");
        return EXIT_FAILURE;
    }

    if((getuid() != 0) && (getuid() != file_stat.st_uid))
    {
        fprintf(stderr, "Insufficient permission to modify ACL of %s\n", File);
        return EXIT_FAILURE;
    }

    char *acl_str = (char *)malloc(MAX_ATTRIBUTE_LEN * sizeof(char));
    acl_str[0] = '\0';

    ssize_t size = getxattr(File, ACL_ATTRIBUTE, acl_str, MAX_ATTRIBUTE_LEN);

    if(size < 0 && errno != ENODATA){
        perror("getxattr");
        return EXIT_FAILURE;
    }

    if(u_name != NULL)
    {
        int i;
        int j;

        string_search(acl_str, u_name, &i, &j);

        if(i == -1)
        {
            strcat(acl_str, "Username:");
            strcat(acl_str, u_name);
            strcat(acl_str, " : ");
            strcat(acl_str, permission);
            strcat(acl_str, "\n");
        }
        else
        {
            strncpy(&acl_str[j + 1], permission, 3);
        }
    }

    if(gr_name != NULL)
    {
        int i;
        int j;

        string_search(acl_str, gr_name, &i, &j);

        if(i == -1)
        {
            strcat(acl_str, "GroupName:");
            strcat(acl_str, gr_name);
            strcat(acl_str, " : ");
            strcat(acl_str, permission);
            strcat(acl_str, "\n");
        }
        else
        {
            strncpy(&acl_str[j + 1], permission, 3);
        }
    }
    
    if(setxattr(File, ACL_ATTRIBUTE, acl_str, strlen(acl_str), 0) < 0)
    {
        perror("setxattr");
        return EXIT_FAILURE;
    }

    printf("Permissions successfully set.\n");
    return 0;
}