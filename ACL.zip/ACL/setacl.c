#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <sys/types.h>
#include <sys/access.h>
#include <pwd.h>
#include <grp.h>
#include <errno.h>

#define ACL_ATTRIBUTE "user.acl"
#define MAX_ATTRIBUTE_LEN 10000

bool is_permitted(const char *permission)
{
    bool check1 = (strlen(permission) != 3);
    bool check2 = (permission[0] != 'r');
    bool check3 = (permission[0] != '-');
    bool check4 = (permission[1] != 'w');
    bool check5 = (permission[1] != '-');
    bool check6 = (permission[2] != 'x');
    bool check7 = (permission[2] != 's');
    bool check8 = (permission[2] != '-');
    bool check9 = (permission[2] == 's');
    bool check10 = (permission[0] == '-');
    bool check11 = (permission[1] == '-');

    bool condition = (check1 || (check2 && check3) || (check4 && check5) || (check6 && check7 && check8) || (check9 && check10 && check11));

    if(condition)
        return 0;

    return 1;
}

void string_search(char *str, char *pattern, int *i, int *j) {
    char *temp[100];
    snprintf(temp, sizeof(temp), "user: %s: ", pattern);

    char *match = strstr(str, temp);
    bool condition = (match == NULL);

    if(condition)
    {
        *i = -1;
        *j = -1;
    } 
    else
    {
        *i = match - str;
        *j = *i + strlen(temp) - 1;
    }
}

int main(int argc, char **argv)
{
    int opt;
    char *u_name = NULL;
    char *gr_name = NULL;
    char *permission = NULL;
    char *File = NULL;
    bool rm_acl = false;
    bool condition = ((opt = getopt(argc, argv, "u:g:p:d")) != -1);

    while(condition)
    {
        switch(opt)
        {
            case 'g':
                gr_name = optarg;
                break;
            case 'u':
                u_name = optarg;
                break;
            case 'd':
                rm_acl = true;
                break;
            case 'p':
                permission = optarg;
                if(is_permitted(permission) == 0)
                {
                    fprintf(stderr, "Action Not Permitted: %s\n", permission);
                    return EXIT_FAILURE;
                }
                break;
            default:
                fprintf(stderr, "Usage: %s [-d] [-u u_name] [-g gr_name] [-p permission] File\n", argv[0]);
                return EXIT_FAILURE;
        }
    }

    struct stat file_stat;
    File = argv[optind];

    condition = (stat(File, &file_stat) < 0);
    if(condition)
    {
        perror("stat");
        return EXIT_FAILURE;
    }
    
    condition = (rm_acl == 1);
    if(condition)
    {
        bool check = (argc != 3);
        if(check)
        {
            fprintf(stderr, "File can be provided with -d flag only.\n");
            return EXIT_FAILURE;
        }

        check = (removexattr(File, ACL_ATTRIBUTE) < 0);
        if(check)
        {
            perror("removexattr");
            return EXIT_FAILURE;
        }

        printf("Permissions successfully removed.\n");
        return 0;
    }

    condition = (permission == NULL);
    if(condition)
    {
        fprintf(stderr, "Permission is required for this action.\n");
        return EXIT_FAILURE;
    }

    condition = (u_name == NULL && gr_name == NULL);
    if(condition)
    {
        fprintf(stderr, "One of -u or -g must be provided for this action.\n");
        return EXIT_FAILURE;
    }

    condition = (optind >= argc);
    if(condition)
    {
        fprintf(stderr, "File must be provided for this action.\n");
        return EXIT_FAILURE;
    }

    condition = ((getuid() != 0) && (getuid() != file_stat.st_uid));
    if(condition)
    {
        fprintf(stderr, "Insufficient permission to modify ACL of %s\n", File);
        return EXIT_FAILURE;
    }

    char *acl_str = (char *)malloc(MAX_ATTRIBUTE_LEN * sizeof(char));
    acl_str[0] = '\0';

    ssize_t size = getxattr(File, ACL_ATTRIBUTE, acl_str, MAX_ATTRIBUTE_LEN);

    condition = (size < 0 && errno != ENODATA);
    if(condition){
        perror("getxattr");
        return EXIT_FAILURE;
    }

    condition = (u_name != NULL);
    if(condition)
    {
        int i;
        int j;

        string_search(acl_str, u_name, &i, &j);

        if(i == -1)
        {
            strcat(acl_str, "Username:");
            strcat(acl_str, u_name);
            strcat(acl_str, " : ");
            strcat(acl_str, permission);
            strcat(acl_str, "\n");
        }
        else
        {
            strncpy(&acl_str[j + 1], permission, 3);
        }
    }

    condition = (gr_name != NULL);
    if(condition)
    {
        int i;
        int j;

        string_search(acl_str, gr_name, &i, &j);

        if(i == -1)
        {
            strcat(acl_str, "GroupName:");
            strcat(acl_str, gr_name);
            strcat(acl_str, " : ");
            strcat(acl_str, permission);
            strcat(acl_str, "\n");
        }
        else
        {
            strncpy(&acl_str[j + 1], permission, 3);
        }
    }
    
    condition = (setxattr(File, ACL_ATTRIBUTE, acl_str, strlen(acl_str), 0) < 0);
    if(condition)
    {
        perror("setxattr");
        return EXIT_FAILURE;
    }

    printf("Permissions successfully set.\n");
    return 0;
}