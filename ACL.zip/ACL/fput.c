#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <errno.h>

#define ACL_ATTRIBUTE "user.acl"

bool is_dac_write_permitted(const char *File, uid_t uid)
{
    struct stat file_info;

    if(stat(File, &file_info) < 0)
    {
        perror("stat");
        return 0;
    }

    if(uid == file_info.st_uid)
    {
        if(file_info.st_mode & S_IWUSR){
            return 1;
        }
    }

    if(file_info.st_mode & S_IWOTH){
        return 1;
    }

    if(access(File, W_OK) == 0){
        return 1;
    }

    return 0;
}

void helper_func_pwd(char *target, struct passwd *pw, int permission_code)
{
    if(permission_code == 6)
        snprintf(target, sizeof(target), "user:%s:rw", pw->pw_name);
    else
        snprintf(target, sizeof(target), "user:%s:-w", pw->pw_name);
}

void helper_func_gr(char *target, struct group *gr, int permission_code)
{
    if(permission_code == 6)
        snprintf(target, sizeof(target), "group:%s:rw", gr->gr_name);
    else
        snprintf(target, sizeof(target), "group:%s:-w", gr->gr_name);
}

bool is_acl_write_permitted(const char *File, uid_t u_uid)
{
    char acl_str[1024];
    ssize_t size = getxattr(File, ACL_ATTRIBUTE, acl_str, sizeof(acl_str));

    if((size < 0) && (errno == ENODATA)){
        fprintf(stderr, "Falling back to DAC, no ACL found...\n");
        return is_dac_write_permitted(File, u_uid);
    }

    char target_str[512];
    struct passwd *pw = getpwuid(u_uid);

    if(strstr(acl_str, pw->pw_name) == NULL){
        return is_dac_write_permitted(File, u_uid);
    }

    helper_func_pwd(target_str, pw, 6);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    helper_func_pwd(target_str, pw, 2);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    struct group *gr = getgrgid(pw->pw_gid);

    helper_func_gr(target_str, gr, 6);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    helper_func_gr(target_str, gr, 2);
    if(strstr(acl_str, target_str) != NULL){
        return 1;
    }

    return is_dac_write_permitted(File, u_uid);
}

int main(int argc, char *argv[])
{
    if(argc != 3)
    {
        fprintf(stderr, "Usage: %s <string> <File>\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE *f;
    char *data = argv[1];
    char *File = argv[2];
    uid_t u_uid = getuid();

    if(!is_acl_write_permitted(File, u_uid))
    {
        fprintf(stderr, "Insufficient Permission to write to file: %s.\n", File);
        return EXIT_FAILURE;
    }

    f = fopen(File, "a");

    if(f == NULL)
    {
        printf("Unable to create or open file: '%s'.\n", File);
        return EXIT_FAILURE;
    }

    if(fprintf(f, "%s", data) < 0)
    {
        fprintf(stderr, "Error writing data to file: '%s'.\n", File);
        fclose(f);
        return EXIT_FAILURE;
    }

    fclose(f);
    printf("Successfully written data to the file: '%s'.\n", File);

    return 0;
}