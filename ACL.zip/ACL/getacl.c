#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <sys/types.h>
#include <sys/access.h>
#include <pwd.h>
#include <grp.h>
#include <errno.h>

#define ACL_ATTRIBUTE "user.acl"
#define MAX_ATTRIBUTE_LEN 10000

bool is_dac_read_permitted(const char *File)
{
    struct stat file_info;
    bool condition;

    condition = (stat(File, &file_info) < 0);
    if(condition)
    {
        perror("stat");
        return 0;
    }

    condition = (access(File, R_OK) == 0);
    if(condition){
        return 1;
    }

    return 0;
}

int main(int argc, char **argv)
{
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <File>\n", argv[0]);
        return EXIT_FAILURE;
    }

    char *File = argv[1];
    struct stat file_info;
    bool condition = (stat(File, &file_info) < 0);

    if(condition){
        perror("stat");
        return EXIT_FAILURE
    }

    condition = (is_dac_read_permitted(File)==0);
    if(condition){
        fprintf(stderr, "Insufficient Privileges to view ACLs for the file: %s.\n", File);
        return EXIT_FAILURE;
    }
    
    char *acl_str = (char *)malloc(MAX_ATTRIBUTE_LEN * sizeof(char));
    acl_str[0] = '\0';

    ssize_t size = getxattr(File, ACL_ATTRIBUTE, acl_str, MAX_ATTRIBUTE_LEN);

    condition = (size<0 && errno==ENODATA)
    if(condition)
    {
        fprintf(stderr, "ACL not set for the file: %s.\n", File);
        return EXIT_FAILURE;
    }

    struct passwd *pw = getpwuid(file_info.st_uid);
    struct group  *gr = getgrgid(file_info.st_gid);

    printf("$ Name of the File: %s\n", File);
    printf("$ Owner of the File: %s\n", pw->pw_name);
    printf("$ Group of the File: %s\n", gr->gr_name);

    printf("ACL String %s\n", acl_str);

    return 0;
}