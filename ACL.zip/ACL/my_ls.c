#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <dirent.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>
#include <errno.h>

#define ACL_ATTRIBUTE "user.acl"

bool is_dac_read_permitted(const char *path, uid_t uid) {
    struct stat file_info;
    if (stat(path, &file_info) < 0) {
        perror("stat");
        return false;
    }
    if (uid == file_info.st_uid && (file_info.st_mode & S_IRUSR)) {
        return true;
    }
    if (file_info.st_mode & S_IROTH) {
        return true;
    }
    return access(path, R_OK) == 0;
}

bool is_acl_read_permitted(const char *path, uid_t uid) {
    char acl_str[1024];
    ssize_t size = getxattr(path, ACL_ATTRIBUTE, acl_str, sizeof(acl_str));
    if ((size < 0) && (errno == ENODATA)) {
        fprintf(stderr, "No ACL found, falling back to DAC...\n");
        return is_dac_read_permitted(path, uid);
    }
    struct passwd *pw = getpwuid(uid);
    if (!pw || !strstr(acl_str, pw->pw_name)) {
        return is_dac_read_permitted(path, uid);
    }
    char target_str[512];
    snprintf(target_str, sizeof(target_str), "user:%s:r", pw->pw_name);
    if (strstr(acl_str, target_str)) {
        return true;
    }
    struct group *gr = getgrgid(pw->pw_gid);
    snprintf(target_str, sizeof(target_str), "group:%s:r", gr->gr_name);
    return strstr(acl_str, target_str) != NULL;
}

void drop_privileges(uid_t new_uid) {
    if (seteuid(new_uid) < 0) {
        perror("seteuid");
        exit(EXIT_FAILURE);
    }
}

void list_directory(const char *path, uid_t uid) {
    struct stat dir_info;
    if (stat(path, &dir_info) < 0) {
        perror("stat");
        exit(EXIT_FAILURE);
    }
    if (!is_acl_read_permitted(path, uid)) {
        fprintf(stderr, "Insufficient permission to read directory: %s\n", path);
        exit(EXIT_FAILURE);
    }
    drop_privileges(dir_info.st_uid);
    DIR *dir = opendir(path);
    if (!dir) {
        perror("opendir");
        exit(EXIT_FAILURE);
    }
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        printf("%s\n", entry->d_name);
    }
    closedir(dir);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <directory>\n", argv[0]);
        return EXIT_FAILURE;
    }
    uid_t uid = getuid();
    list_directory(argv[1], uid);
    return EXIT_SUCCESS;
}